<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Pages extends Model
{
    //
    protected $table 		= "pages";
    const CREATED_AT        = 'created_at';
    const UPDATED_AT        = 'updated_at';


}
