<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Inquiry extends Model
{
    
    protected $table 	= "inquiry";
    protected $fillable = ['status'];
    
}
