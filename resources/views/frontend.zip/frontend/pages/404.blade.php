@section('contant')
    <!-- section -->
         <div class="section about_section layout_padding padding_top_0">
            <div class="container">
               <div class="row">
                  <div class="col-md-12 pb-5">
                     <div class="full">
                        <div class="heading_main text_align_center pt-5">
                            404 Page
                        </div>
                     </div>
                  </div>
               </div>
              
            </div>
         </div>
         <!-- end section -->
@stop